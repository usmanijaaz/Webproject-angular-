export class Courses {
  'title': string;
  'subTitle': string;
  'description': string;
  'imageUrl': string;
  'outterClass': string;
  'middleClass': string;
  'innerClass': string;
  'title1': string;
  'description1': string;
  'imageUrl1': string;
  'mainDescription': string;
}
