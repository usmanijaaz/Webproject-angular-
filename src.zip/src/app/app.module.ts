import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './Mycomponent/sidebar/sidebar.component';
import { DivImageSComponent } from './Mycomponent/div-image-s/div-image-s.component';
import { BaseComponentComponent } from './Mycomponent/base-component/base-component.component';
import { NavbarComponent } from './Mycomponent/navbar/navbar.component';
import { BaseComponent } from './Mycomponent/base/base.component';
import { FooterComponent } from './Mycomponent/footer/footer.component';
import { LoginComponent } from './Mycomponent/login/login.component';
import { FormsModule } from "@angular/forms";
import { SocialLoginModule,SocialAuthServiceConfig } from "angularx-social-login";
import { GoogleLoginProvider,FacebookLoginProvider } from "angularx-social-login";
@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    DivImageSComponent,
    BaseComponentComponent,
    NavbarComponent,
    BaseComponent,
    FooterComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, 
    SocialLoginModule
  ],
  providers: [{
    provide: "SocialAuthServiceConfig",
    useValue: {
      autoLogin: true,
      providers: [
        {
          id: GoogleLoginProvider.PROVIDER_ID,
          provider: new GoogleLoginProvider(
            "734767924768-fakdi2m98gal085cegliu3ga2c161s50.apps.googleusercontent.com"
          )
        },
        {
          id: FacebookLoginProvider.PROVIDER_ID,
          provider: new FacebookLoginProvider('649342052781163')
        }
      ]
    } as SocialAuthServiceConfig
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
